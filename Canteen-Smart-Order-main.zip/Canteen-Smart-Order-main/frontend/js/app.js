// ===== APP STATE =====
// Force clear menu cache during development to apply data.js changes
localStorage.removeItem('cso_menus');

const App = {
  currentPage: 'login',
  role: null, // 'customer','vendor','admin'
  user: null,
  cart: [],
  orders: [...MOCK_ORDERS],
  notifications: [],
};

// ===== ROUTER =====
function navigate(page) {
  App.currentPage = page;
  render();
}

function render() {
  const root = document.getElementById('app');
  const p = App.currentPage;
  if (p === 'login') { root.innerHTML = loginPage(); }
  else if (App.role === 'customer') { root.innerHTML = customerLayout(p); }
  else if (App.role === 'vendor') { root.innerHTML = vendorLayout(p); }
  else if (App.role === 'admin') { root.innerHTML = adminLayout(p); }
  attachEvents();
  saveState();
}

// ===== HELPERS =====
function showToast(msg, type = '') {
  const c = document.getElementById('toasts');
  if (!c) return;
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<span class="toast-icon">${type==='success'?'✅':type==='error'?'❌':'🔔'}</span><span class="toast-msg">${msg}</span>`;
  c.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

function formatPrice(n) { return `฿${n}`; }
function getCartTotal() { return App.cart.reduce((s, i) => s + i.price * i.qty, 0); }
function getCartCount() { return App.cart.reduce((s, i) => s + i.qty, 0); }

function addToCart(menuId) {
  const menu = MENUS.find(m => m.id === menuId);
  if (!menu) return;
  const existing = App.cart.find(c => c.menuId === menuId);
  if (existing) { existing.qty++; }
  else { App.cart.push({ menuId, name: menu.name, price: menu.price, qty: 1, shopId: menu.shopId, note: '' }); }
  showToast(`เพิ่ม ${menu.name} ลงตะกร้าแล้ว`, 'success');
  render();
}

function removeFromCart(menuId) {
  App.cart = App.cart.filter(c => c.menuId !== menuId);
  render();
}

function updateCartQty(menuId, delta) {
  const item = App.cart.find(c => c.menuId === menuId);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) App.cart = App.cart.filter(c => c.menuId !== menuId);
  render();
}

function login(role) {
  App.role = role;
  
  if (role === 'customer') {
    const input = document.querySelector('#form-customer input')?.value.trim().toLowerCase() || 'customer1';
    if (input === 'customer2') App.user = { name: 'สมหญิง รักเรียน', email: 'somying@bu.ac.th', id: 2 };
    else if (input === 'customer3') App.user = { name: 'วรวิทย์ เก่งมาก', email: 'worawit@bu.ac.th', id: 3 };
    else if (input === 'customer4') App.user = { name: 'กานดา สวยงาม', email: 'kanda@bu.ac.th', id: 4 };
    else App.user = { name: 'สมชาย ใจดี', email: 'somchai@bu.ac.th', id: 1 };
  } else if (role === 'vendor') {
    const input = document.querySelector('#form-vendor input')?.value.trim().toLowerCase() || 'vendor1';
    const v = VENDORS.find(ven => ven.username === input) || VENDORS[0];
    App.user = { name: v.name, owner: v.owner, id: v.id };
  } else {
    App.user = { name: 'ผู้ดูแลระบบ', id: 0 };
  }
  
  navigate(role === 'customer' ? 'menu' : role === 'vendor' ? 'v-orders' : 'a-dashboard');
  showToast(`ยินดีต้อนรับ ${App.user.name}`, 'success');
}

function logout() { App.role = null; App.user = null; App.cart = []; navigate('login'); }

// ===== ATTACH EVENTS =====
function attachEvents() {
  document.querySelectorAll('[data-nav]').forEach(el => {
    el.onclick = (e) => { e.preventDefault(); e.stopPropagation(); navigate(el.dataset.nav); };
  });
  document.querySelectorAll('[data-action]').forEach(el => {
    el.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      const a = el.dataset.action;
      const v = el.dataset.value;
      if (a === 'login') login(v);
      else if (a === 'logout') logout();
      else if (a === 'add-cart') addToCart(parseInt(v));
      else if (a === 'remove-cart') removeFromCart(parseInt(v));
      else if (a === 'cart-inc') { updateCartQty(parseInt(v), 1); }
      else if (a === 'cart-dec') { updateCartQty(parseInt(v), -1); }
      else if (a === 'place-order') { document.getElementById('payment-modal')?.classList.remove('active'); placeOrder(); }
      else if (a === 'cancel-order') { document.getElementById('cancel-order-id').value = v; document.getElementById('cancel-modal').classList.add('active'); }
      else if (a === 'confirm-cancel') { const id = document.getElementById('cancel-order-id').value; document.getElementById('cancel-modal').classList.remove('active'); cancelOrder(id); }
      else if (a === 'reschedule-order') { document.getElementById('reschedule-order-id').value = v; document.getElementById('reschedule-modal').classList.add('active'); }
      else if (a === 'confirm-reschedule') { const id = document.getElementById('reschedule-order-id').value; const time = document.getElementById('new-pickup-time').value; document.getElementById('reschedule-modal').classList.remove('active'); rescheduleOrder(id, time); }
      else if (a === 'accept-order') updateOrderStatus(v, 'cooking');
      else if (a === 'reject-order') { document.getElementById('reject-order-id').value = v; document.getElementById('reject-modal').classList.add('active'); }
      else if (a === 'confirm-reject') { const id = document.getElementById('reject-order-id').value; document.getElementById('reject-modal').classList.remove('active'); updateOrderStatus(id, 'cancelled'); }
      else if (a === 'ready-order') updateOrderStatus(v, 'ready');
      else if (a === 'complete-order') updateOrderStatus(v, 'completed');
      else if (a === 'suspend-vendor') {
        document.getElementById('suspend-vendor-id').value = v;
        document.getElementById('suspend-shop-name').textContent = el.dataset.name;
        document.getElementById('suspend-owner-name').textContent = el.dataset.owner;
        document.getElementById('suspend-reason').value = '';
        document.getElementById('suspend-modal').classList.add('active');
      }
      else if (a === 'confirm-suspend') {
        const id = parseInt(document.getElementById('suspend-vendor-id').value);
        const reason = document.getElementById('suspend-reason').value;
        if(!reason) { showToast('กรุณาระบุเหตุผลการระงับบัญชี', 'error'); return; }
        document.getElementById('suspend-modal').classList.remove('active');
        suspendVendor(id, reason);
      }
      else if (a === 'unsuspend-vendor') unsuspendVendor(parseInt(v));
      else if (a === 'add-vendor') {
        document.getElementById('new-vendor-name').value = '';
        document.getElementById('new-vendor-owner').value = '';
        document.getElementById('new-vendor-username').value = '';
        document.getElementById('add-vendor-modal').classList.add('active');
      }
      else if (a === 'confirm-add-vendor') { addVendor(); }
      else if (a === 'create-announcement') createAnnouncement();
      else if (a === 'delete-announcement') deleteAnnouncement(parseInt(v));
      else if (a === 'toggle-menu') toggleMenuAvail(parseInt(v));
      else if (a === 'toggle-notif') toggleNotifDropdown();
      else if (a === 'toggle-mobile-nav') toggleMobileNav();
      else if (a === 'toggle-sidebar') toggleSidebar();
      else if (a === 'track-order') { App.selectedOrder = v; navigate('track'); }
      else if (a === 'cancel-order') {
        document.getElementById('cancel-order-id').value = v;
        document.getElementById('cancel-modal').classList.add('active');
      }
      else if (a === 'confirm-cancel') {
        const id = document.getElementById('cancel-order-id').value;
        document.getElementById('cancel-modal').classList.remove('active');
        updateOrderStatus(id, 'cancelled');
      }
      else if (a === 'reschedule-order') {
        document.getElementById('reschedule-order-id').value = v;
        document.getElementById('reschedule-modal').classList.add('active');
      }
      else if (a === 'confirm-reschedule') {
        const id = document.getElementById('reschedule-order-id').value;
        const newTime = document.getElementById('new-pickup-time').value;
        document.getElementById('reschedule-modal').classList.remove('active');
        const order = App.orders.find(o => o.id === id);
        if (order) {
          order.pickupTime = newTime;
          showToast('เลื่อนเวลารับอาหารสำเร็จ', 'success');
          render();
        }
      }
    };
  });
}

function placeOrder() {
  if (App.cart.length === 0) { showToast('กรุณาเพิ่มอาหารลงตะกร้า', 'error'); return; }
  const timeEl = document.getElementById('pickup-time');
  const pickupTime = timeEl ? timeEl.value : '12:00';
  
  // Group items by shop to support ordering from multiple shops
  const shopGroups = {};
  App.cart.forEach(item => {
    if (!shopGroups[item.shopId]) shopGroups[item.shopId] = [];
    shopGroups[item.shopId].push(item);
  });

  Object.keys(shopGroups).forEach(shopIdStr => {
    const shopId = parseInt(shopIdStr);
    const shop = SHOPS.find(s => s.id === shopId);
    const items = shopGroups[shopIdStr];
    const total = items.reduce((sum, i) => sum + i.price * i.qty, 0);
    
    const order = {
      id: 'ORD-' + String(App.orders.length + 1).padStart(3, '0'),
      customerId: App.user.id, 
      customerName: App.user.name,
      shopId: shopId, 
      shopName: shop ? shop.name : '', 
      items: items,
      total: total, 
      status: 'pending', 
      pickupTime: pickupTime,
      orderDate: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
    };
    App.orders.unshift(order); // Add to beginning of orders
  });

  App.cart = [];
  showToast('สั่งอาหารสำเร็จ! ระบบได้ส่งออเดอร์ไปยังร้านค้าแล้ว', 'success');
  navigate('my-orders');
}

function cancelOrder(orderId) {
  const order = App.orders.find(o => o.id === orderId);
  if (order && order.status === 'pending') {
    order.status = 'cancelled';
    showToast('ยกเลิกคำสั่งซื้อสำเร็จ', 'success');
    render();
  } else { showToast('ไม่สามารถยกเลิกได้ เนื่องจากร้านค้าเริ่มทำอาหารแล้ว', 'error'); }
}

function rescheduleOrder(orderId, time) {
  const order = App.orders.find(o => o.id === orderId);
  if (order && order.status === 'pending') {
    order.pickupTime = time;
    showToast(`เลื่อนเวลาเป็น ${time} สำเร็จ`, 'success');
    render();
  } else { showToast('ไม่สามารถเลื่อนเวลาได้', 'error'); }
}

function updateOrderStatus(orderId, status) {
  const order = App.orders.find(o => o.id === orderId);
  if (order) { order.status = status; showToast(`อัปเดตสถานะ ${STATUS_MAP[status].label} สำเร็จ`, 'success'); render(); }
}

function generatePickupTimeSlots() {
  const dynamicSlots = [];
  const now = new Date();
  let start = new Date(now.getTime() + 10 * 60000); // +10 minutes minimum prep time
  const remainder = start.getMinutes() % 5;
  if (remainder !== 0) start = new Date(start.getTime() + (5 - remainder) * 60000);

  for (let i = 0; i < 12; i++) {
    const hours = start.getHours().toString().padStart(2, '0');
    const mins = start.getMinutes().toString().padStart(2, '0');
    const timeString = `${hours}:${mins}`;
    if (start.getHours() >= 20) break;
    dynamicSlots.push(timeString);
    start = new Date(start.getTime() + 10 * 60000); // 10-minute intervals
  }
  if (dynamicSlots.length === 0) dynamicSlots.push("หมดเวลาทำการ");
  return dynamicSlots;
}

function suspendVendor(vendorId, reason) {
  const vendor = VENDORS.find(v => v.id === vendorId);
  if (vendor) {
    vendor.status = 'suspended';
    vendor.suspendReason = reason;
    showToast(`ระงับบัญชีร้าน ${vendor.name} สำเร็จ`, 'success');
    render();
  }
}

function unsuspendVendor(vendorId) {
  const vendor = VENDORS.find(v => v.id === vendorId);
  if (vendor) {
    vendor.status = 'active';
    delete vendor.suspendReason;
    showToast(`เปิดใช้งานบัญชีร้าน ${vendor.name} เรียบร้อยแล้ว`, 'success');
    render();
  }
}

function addVendor() {
  const name = document.getElementById('new-vendor-name').value.trim();
  const owner = document.getElementById('new-vendor-owner').value.trim();
  const username = document.getElementById('new-vendor-username').value.trim();
  
  if (!name || !owner || !username) {
    showToast('กรุณากรอกข้อมูลให้ครบถ้วน', 'error');
    return;
  }
  
  // Check duplicate username
  if (VENDORS.find(v => v.username.toLowerCase() === username.toLowerCase())) {
    showToast('ชื่อบัญชีนี้มีอยู่ในระบบแล้ว กรุณาใช้ชื่ออื่น', 'error');
    return;
  }
  
  const id = VENDORS.length ? Math.max(...VENDORS.map(v => v.id)) + 1 : 1;
  VENDORS.push({ id, name, owner, username, status: 'active', totalOrders: 0, revenue: 0 });
  
  document.getElementById('add-vendor-modal').classList.remove('active');
  showToast(`เพิ่มร้านค้า ${name} สำเร็จ`, 'success');
  render();
}

function filterAdminVendors() {
  const query = document.getElementById('admin-vendor-search').value.toLowerCase();
  const rows = document.querySelectorAll('.vendor-row');
  rows.forEach(row => {
    const name = row.dataset.name;
    const username = row.dataset.username;
    const owner = row.dataset.owner;
    if (name.includes(query) || username.includes(query) || owner.includes(query)) {
      row.style.display = '';
    } else {
      row.style.display = 'none';
    }
  });
}



function createAnnouncement() {
  const title = document.getElementById('announce-title').value.trim();
  const message = document.getElementById('announce-message').value.trim();
  const target = document.getElementById('announce-target').value;
  if (!title || !message) {
    showToast('กรุณากรอกหัวข้อและรายละเอียดประกาศ', 'error');
    return;
  }
  const newAnnounce = {
    id: ANNOUNCEMENTS.length > 0 ? Math.max(...ANNOUNCEMENTS.map(a=>a.id)) + 1 : 1,
    title: title,
    message: message,
    target: target,
    date: new Date().toISOString().split('T')[0],
    active: true
  };
  ANNOUNCEMENTS.unshift(newAnnounce);
  saveState();
  showToast('เผยแพร่ประกาศเรียบร้อยแล้ว!', 'success');
  render();
}

function deleteAnnouncement(id) {
  const index = ANNOUNCEMENTS.findIndex(a => a.id === id);
  if (index > -1) {
    ANNOUNCEMENTS.splice(index, 1);
    saveState();
    showToast('ลบประกาศเรียบร้อยแล้ว', 'success');
    render();
  }
}

function toggleMenuAvail(menuId) {
  const menu = MENUS.find(m => m.id === menuId);
  if (menu) { menu.available = !menu.available; showToast(`${menu.name}: ${menu.available ? 'เปิดขาย' : 'ปิดขาย'}`, 'success'); render(); }
}

function toggleNotifDropdown() {
  const d = document.querySelector('.notif-dropdown');
  if (d) d.classList.toggle('show');
}
function toggleMobileNav() {
  const n = document.querySelector('.navbar-nav');
  if (n) n.classList.toggle('open');
}
function toggleSidebar() {
  const s = document.querySelector('.sidebar');
  if (s) s.classList.toggle('open');
}

function showPushNotification() {
  const c = document.body;
  const t = document.createElement('div');
  t.innerHTML = `
    <div style="display:flex; gap:12px; align-items:center; background:rgba(255,255,255,0.95); backdrop-filter:blur(10px); padding:16px; border-radius:16px; box-shadow:0 10px 40px rgba(0,0,0,0.2); width:340px; border:1px solid rgba(0,0,0,0.05); cursor:pointer;">
      <div style="width:40px; height:40px; background:var(--primary); border-radius:10px; display:flex; align-items:center; justify-content:center; color:white; font-size:1.2rem;">🍽️</div>
      <div style="flex:1; text-align:left;">
        <div style="display:flex; justify-content:space-between; margin-bottom:4px">
          <span style="font-weight:700; font-size:0.9rem; color:var(--primary-dark)">Canteen Smart Order</span>
          <span style="font-size:0.75rem; color:var(--gray)">ตอนนี้</span>
        </div>
        <p style="font-size:0.85rem; color:#333; margin:0">✅ <strong>อาหารพร้อมเสิร์ฟแล้ว!</strong><br><span style="color:var(--gray)">กรุณามารับที่ร้าน ภายใน 10 นาที</span></p>
      </div>
    </div>
  `;
  t.style.position = 'fixed';
  t.style.top = '-100px';
  t.style.left = '50%';
  t.style.transform = 'translateX(-50%)';
  t.style.zIndex = '9999';
  t.style.transition = 'all 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
  
  c.appendChild(t);
  
  setTimeout(() => { t.style.top = '20px'; }, 50);
  setTimeout(() => { t.style.top = '-150px'; t.style.opacity = '0'; }, 4000);
  setTimeout(() => { t.remove(); }, 4600);
}

// ===== DATA SYNC (CROSS-TAB & PERSISTENCE) =====
// Data persistence disabled - using temporary mock data only
function saveState() {
  // Disabled: Data will not be saved permanently
}

function loadState() {
  // Disabled: Always load fresh mock data from data.js
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  loadState();
  render();
});
